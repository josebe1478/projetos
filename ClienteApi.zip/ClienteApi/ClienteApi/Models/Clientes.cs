﻿using System.ComponentModel.DataAnnotations;

namespace ClienteApi.Models;


public class Clientes
{
    [Key]
    public int Id { get; set; }
    public string? Nome { get; set; }
    public string? Email { get; set; }
    public string? Cpf { get; set; }
    public DateTime Nascimento { get; set; }
}
