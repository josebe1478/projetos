﻿using Microsoft.EntityFrameworkCore;
using ClienteApi.Data;
using ClienteApi.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.OpenApi;
namespace ClienteApi;

public static class ClientesEndpoints
{
    public static void MapClientesEndpoints (this IEndpointRouteBuilder routes)
    {
        var group = routes.MapGroup("/api/Clientes").WithTags(nameof(Clientes));

        group.MapGet("/", async (ClienteApiContext db) =>
        {
            return await db.Clientes.ToListAsync();
        })
        .WithName("GetAllClientes")
        .WithOpenApi();

        group.MapGet("/{id}", async Task<Results<Ok<Clientes>, NotFound>> (int id, ClienteApiContext db) =>
        {
            return await db.Clientes.AsNoTracking()
                .FirstOrDefaultAsync(model => model.Id == id)
                is Clientes model
                    ? TypedResults.Ok(model)
                    : TypedResults.NotFound();
        })
        .WithName("GetClientesById")
        .WithOpenApi();

        group.MapPut("/{id}", async Task<Results<Ok, NotFound>> (int id, Clientes clientes, ClienteApiContext db) =>
        {
            var affected = await db.Clientes
                .Where(model => model.Id == id)
                .ExecuteUpdateAsync(setters => setters
                    .SetProperty(m => m.Id, clientes.Id)
                    .SetProperty(m => m.Nome, clientes.Nome)
                    .SetProperty(m => m.Email, clientes.Email)
                    .SetProperty(m => m.Cpf, clientes.Cpf)
                    .SetProperty(m => m.Nascimento, clientes.Nascimento)
                    );
            return affected == 1 ? TypedResults.Ok() : TypedResults.NotFound();
        })
        .WithName("UpdateClientes")
        .WithOpenApi();

        group.MapPost("/", async (Clientes clientes, ClienteApiContext db) =>
        {
            db.Clientes.Add(clientes);
            await db.SaveChangesAsync();
            return TypedResults.Created($"/api/Clientes/{clientes.Id}",clientes);
        })
        .WithName("CreateClientes")
        .WithOpenApi();

        group.MapDelete("/{id}", async Task<Results<Ok, NotFound>> (int id, ClienteApiContext db) =>
        {
            var affected = await db.Clientes
                .Where(model => model.Id == id)
                .ExecuteDeleteAsync();
            return affected == 1 ? TypedResults.Ok() : TypedResults.NotFound();
        })
        .WithName("DeleteClientes")
        .WithOpenApi();
    }
}
